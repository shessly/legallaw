# Legal Lore

A magazine-style law review journal, inspired by Vogue.  
Only admin (you) can add or edit content. Public can view all sections.

## Getting Started

1. **Clone the repo & install dependencies:**
