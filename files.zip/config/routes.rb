Rails.application.routes.draw do
  devise_for :users
  root "home#index"
  resources :law_of_the_days
  resources :obscure_laws
  resources :law_reviewers
  resources :court_cases
  resources :business_laws
  resources :lore_drops
  get "/about", to: "home#about"
end