class HomeController < ApplicationController
  skip_before_action :authenticate_user!, only: [:index, :about]

  def index
    @law_of_the_day = LawOfTheDay.order(created_at: :desc).first
    @obscure_laws = ObscureLaw.order(created_at: :desc).limit(3)
    @law_reviewers = LawReviewer.order(created_at: :desc).limit(3)
    @court_cases = CourtCase.order(created_at: :desc).limit(3)
    @business_laws = BusinessLaw.order(created_at: :desc).limit(3)
    @lore_drop = LoreDrop.order(created_at: :desc).first
  end

  def about; end
end