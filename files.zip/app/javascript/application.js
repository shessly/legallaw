import "@hotwired/turbo-rails"
import "bootstrap"
import "../stylesheets/application.scss"

// Lore Drop: Vintage Theme Toggle (Optional enhancement)
// You can trigger vintage mode with a URL param or a button. For now, it's applied to the whole lore_drops controller.